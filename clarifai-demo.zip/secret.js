export const API_KEY = '1cdc3b4ac2e540a3b9e844d82bc4b2b6'
